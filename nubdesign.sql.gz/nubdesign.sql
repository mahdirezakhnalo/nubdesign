-- phpMyAdmin SQL Dump
-- version 4.8.4
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Apr 30, 2021 at 02:24 PM
-- Server version: 10.1.37-MariaDB
-- PHP Version: 5.6.40

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `nubdesign`
--

-- --------------------------------------------------------

--
-- Table structure for table `city`
--

CREATE TABLE `city` (
  `city_id` int(11) NOT NULL,
  `city_title` varchar(255) NOT NULL,
  `city_link` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `city`
--

INSERT INTO `city` (`city_id`, `city_title`, `city_link`) VALUES
(1, 'تهران', 'https://www.google.com'),
(2, 'مشهد', 'https://www.google.com');

-- --------------------------------------------------------

--
-- Table structure for table `navigation`
--

CREATE TABLE `navigation` (
  `nav_id` int(11) NOT NULL,
  `nav_title` varchar(255) NOT NULL,
  `nav_link` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `navigation`
--

INSERT INTO `navigation` (`nav_id`, `nav_title`, `nav_link`) VALUES
(1, 'صفحه اصلی', 'index.php'),
(3, 'حساب شخصی', 'account.php'),
(4, 'درباره ی ناب دیزاین', 'about.php'),
(5, 'تیکت ', 'ticket.php'),
(6, 'ارسال تیکت', 'send-ticket.php'),
(8, 'خروج', 'logout.php'),
(9, 'ورود / ثبت نام', 'auth.php');

-- --------------------------------------------------------

--
-- Table structure for table `posts`
--

CREATE TABLE `posts` (
  `post_id` int(11) NOT NULL,
  `user_id` int(9) NOT NULL,
  `post_image` text NOT NULL,
  `post_image2` text NOT NULL,
  `post_image3` text NOT NULL,
  `post_image4` text NOT NULL,
  `post_title` varchar(255) NOT NULL,
  `post_content` text NOT NULL,
  `post_address` text NOT NULL,
  `post_mobile` varchar(11) NOT NULL,
  `post_phone` int(11) NOT NULL,
  `post_date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `posts`
--

INSERT INTO `posts` (`post_id`, `user_id`, `post_image`, `post_image2`, `post_image3`, `post_image4`, `post_title`, `post_content`, `post_address`, `post_mobile`, `post_phone`, `post_date`) VALUES
(2, 0, 'car1.jpg', 'car2.jpg', '۴.jpg', '2.png', 'پست اول', 'بسیار عالی است .', 'جنت آباد جنوبی ، پیامبر غربی', '09395871441', 44094939, '0000-00-00'),
(13, 0, 'home4.jpg', '', 'home2.jpg', '', 'امیر', 'جلوداریان', 'ینبننبنب', '09395871441', 3344, '0000-00-00');

-- --------------------------------------------------------

--
-- Table structure for table `signup`
--

CREATE TABLE `signup` (
  `user_id` int(11) NOT NULL,
  `username` varchar(255) NOT NULL,
  `user_family` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `signup`
--

INSERT INTO `signup` (`user_id`, `username`, `user_family`, `email`, `password`) VALUES
(1, 'mahdi', 'rezakhanlo', 'mahdi@gmail.com', 'mahdi123'),
(2, 'ali', 'tnh', 'mohammadmahdirezakhanlo@gmail.com', 'mahdi123'),
(24, 'maudi', 'daei', 'mohammadmahdirezakhanlo@gmail.com', 'mahdirezakhanlo'),
(25, '', '', '', ''),
(26, '', '', '', ''),
(27, '', '', '', ''),
(28, 'hello', 'hello ', 'fjhfdshfsd@gg.com', 'mmmmmmmm'),
(29, 'hello', 'hello ', 'fjhfdshfsd@gg.com', 'mmmmmmmm'),
(30, 'mahdu', 'FJFJFJD', 'mahdi@gmail.com', '123456789'),
(31, 'asdsds', 'jydgdhdgj', 'ghghjdfghjsdgfhjsdf@gmail.com', 'qwert'),
(32, 'dbhjdbahjb', 'hjbhjsbdhabhjb', 'sdjabda@gmail.com', 'jjjjjjjj'),
(33, 'dsbjfsdbfjsbj', 'bkjdsbkbdjbdkajb', 'bsjdbasda@gmail.com', 'llllllll');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `city`
--
ALTER TABLE `city`
  ADD PRIMARY KEY (`city_id`);

--
-- Indexes for table `navigation`
--
ALTER TABLE `navigation`
  ADD PRIMARY KEY (`nav_id`);

--
-- Indexes for table `posts`
--
ALTER TABLE `posts`
  ADD PRIMARY KEY (`post_id`);

--
-- Indexes for table `signup`
--
ALTER TABLE `signup`
  ADD PRIMARY KEY (`user_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `city`
--
ALTER TABLE `city`
  MODIFY `city_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `navigation`
--
ALTER TABLE `navigation`
  MODIFY `nav_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `posts`
--
ALTER TABLE `posts`
  MODIFY `post_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `signup`
--
ALTER TABLE `signup`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=34;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
